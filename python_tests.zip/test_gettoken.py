# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
testing getting token from webserver
"""

import socket
import sys
import urllib2

def getserial():
  # Extract serial from cpuinfo file
  cpuserial = "0000000000000000"
  try:
    f = open('/proc/cpuinfo','r')
    for line in f:
      if line[0:6]=='Serial':
        cpuserial = line[10:26]
    f.close()
  except:
    cpuserial = "ERROR000000000"
  return cpuserial

def gettoken():
  cpuserial=getserial()
  params='serial="'+getserial()+'"&action=99'
  response=urllib2.urlopen('http://www.d-jundt.org/IoT/log_t.php?'+params).read()
  startpos=response.find('<div id="contentArea">')+22
  response=response[startpos:] #cut formatting in front
  startpos=response.find('</div>')
  response=response[:startpos]
  return response.lstrip().rstrip()
#main program
print gettoken()
