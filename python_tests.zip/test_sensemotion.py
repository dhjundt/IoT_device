# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
function readkey
"""
import RPi.GPIO as GPIO
import time
#globals

# use GPIO connector numbering (B+)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#setup motion input
GPIO.setup(25,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)

def current_now():
#to see if momentary threshold for current (motion) is exceeded
    return GPIO.input(25)

def track10000():
    result=[]
    tstart=time.time()
    initial=0.0
    for i in range(10000):
        result.append(current_now())
        initial=initial+1.0*result[-1]
    print (time.time()-tstart),initial/10000.0 
    return result

def moving():
    initial=0.0
    for i in range(10000):
        initial=initial+1.0*current_now()
    return (initial>0.10)
            
#main program
while True:
    print sum(track10000())/10000.0
    time.sleep(0.3)
