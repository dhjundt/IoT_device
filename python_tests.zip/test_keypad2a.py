# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
function readkey
"""
import RPi.GPIO as GPIO
import time

# library to talk to board
GPIO.setmode(GPIO.BCM)
# use GPIO connector numbering (B+)
GPIO.setwarnings(False)

#setup row outputs
rows=[10,9,11,5]
for i in rows:
    GPIO.setup(i,GPIO.OUT)
    GPIO.output(i,False)

#setup col inputs
cols=[6,13,26]
for c in cols:
    GPIO.setup(c,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)  #1-*; 2-0; 3-#

keymap=[['1','2','3'],['4','5','6'],['7','8','9'],['#','0','#']]

def readkey():
    ans=' '
    for i in range(len(rows)):
        GPIO.output(rows[i],True)
        for j in range(len(cols)):
            if (GPIO.input(cols[j])):
                ans=keymap[i][j]
        GPIO.output(rows[i],False)
    return ans

#main loop - will need to change

#timing
start_time=time.time()
for i in range (1000):
    resp=readkey()
print 'time in ms per scan across'
duration= (time.time()-start_time)
print duration

#now allow for 30 seconds (printing will slow)
for i in range(int( 30*1000/duration)):
    resp=readkey()
    if resp<>' ':
        print resp
print 'done'

            
                
