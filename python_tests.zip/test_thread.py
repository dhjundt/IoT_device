# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
testing threading and queues
"""

import Queue as qu
import threading as td
import time #just for demo purposes
import random #so we can simulate random delay in demo

def doslowprocess():
    while True:
        status_to_transmit=q.get()
        dur=random.randint(2,8)
        print 'received ',status_to_transmit, ' duration: ',dur
        time.sleep(dur) #to simulate some delay in internet transmission
        print 'done with duration ',dur
        q.task_done() #to remove task from queue

#main program
q=qu.Queue()
t=td.Thread(target=doslowprocess)
t.daemon=True
t.start()

for i in range(60): #do it for 1 minute total
    time.sleep(1)
    if i%6==0: #send something to slow process ever 6 seconds
        q.put_nowait(i+100)
    print '.'
