# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
function readkey
"""
import RPi.GPIO as GPIO
import time
#globals
secretcode=['1','2','3','7','8','9']
codeinput=[]
codetimeout=10 #after first button, need to finish in time
tminbutton=0.05 #minimum time a button needs to be pressed to be accepted
tcodestart=0.0
prevval=(False,' ',0.0)
tstart=0.0

# use GPIO connector numbering (B+)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#setup row outputs
rows=[10,9,11,5]
for i in rows:
    GPIO.setup(i,GPIO.OUT, initial=GPIO.LOW)
#LED output
GPIO.setup(24,GPIO.OUT, initial=GPIO.LOW)

#RELAY output
GPIO.setup(23,GPIO.OUT, initial=GPIO.LOW)

#setup col inputs
cols=[6,13,26]
for c in cols:
    GPIO.setup(c,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)  #1-*; 2-0; 3-#

#setup closed switch input
GPIO.setup(18,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)

def setLED(on):
#setLED is used to show a key is pressed or code was wrong
    GPIO.output(24,on)

def blinkLED():
#after wrong input,call this to blink for 3sec
    for i in range(15):
        setLED(True)
        time.sleep(0.1)
        setLED(False)
        time.sleep(0.1)    

def pushbutton():
#simulates the button being pushed, initiating motion
    GPIO.output(23,True)
    time.sleep(1)
    GPIO.output(23,False)
    
def isclosed():
#checks if door is closed
    return GPIO.input(18)
    
def readkey():
#    report tuple (button pressed, char, time pressed)
#    only reports character if 'button pressed'=False (when finger lifted)
#    and button had been pressed for a minimum amount of time
    keymap=[['1','2','3'],['4','5','6'],['7','8','9'],['#','0','#']]
    global prevval, tstart, tminbutton
    previous=prevval
    ans=' '
    for i in range(len(rows)):
        GPIO.output(rows[i],True)
        for j in range(len(cols)):
            if (GPIO.input(cols[j])):
                ans=keymap[i][j]
        GPIO.output(rows[i],False)
    if ans==' ': #not pressed now
        if (previous[0]): #first no longer pressed
            setLED(False)
            if time.time()-tstart>tminbutton:
                prevval=(False,previous[1],time.time()-tstart)
            else: #too short
                prevval=(False,' ',0.0)
        else: 
            prevval=(False,' ',0.0)
    else: #pressed now
        if (previous[0]): #also previously
            prevval = (True,ans,0.0)
        else:
            tstart=time.time()
            setLED(True)
            prevval = (True,ans,time.time()-tstart)            
    return prevval

def input_started():
# this does a sweep and checks if any key pressed (quick)
    return(readkey()[0])

def enter_key():
# called once a key is pressed
# will return true as soon as key released if it is #
    timeout=60 #should never occur
    ans='some value'
    if input_started():
        t0=time.time()
        while (time.time()-t0)<timeout:
            ans=readkey()
            if ans[2]<>0.0:
                break
        return (ans[1]=='#')
    else:
        return False
    
def checkcode(secret):
#   calls readkey() and checks if correct after enter is hit
#   either reports empty string (still waiting for more input)
#   or 'correct' or 'wrong' or 'timeout' if it took longer than codetimeout
    global codetimeout, tcodestart, codeinput
    if ((time.time()-tcodestart>codetimeout) and (tcodestart>0.0)):
        codeinput=[]
        tcodestart=0.0
        blinkLED()        
        return 'timeout'
    else: #not timed out
        (on,char,ton)=readkey() #do one sweep
        if (on==True or char==' '): #no entry - no action
            return ''
        else: #a new key was pressed
            if (char=='#'): #check for correct input
                if (codeinput==secret):
                    codeinput=[]
                    tcodestart=0.0
                    return 'correct'
                else: # enter but not correct
                    codeinput=[]
                    tcodestart=0.0
                    blinkLED()
                    return 'wrong'
            else: # a key other than enter pressed
                if (len(codeinput)==0):
                    tcodestart=time.time()
                codeinput.append(char)
                print codeinput
                return ''

def enter_code(secret):
# called once a key is pressed (alternate to enter_key()
# will return string after code entry complete or timed out
    if input_started():
        while True:
            ret=checkcode(secret)
            if ret<>'':
                break
        return ret
    else:
        return ''
                   
#main program
print 'push any buttons (total of 3 pushes)'
print 'secret code is',secretcode

"""
events=0
while events<3:
    msg= checkcode(secretcode)
    if msg<>'':
        events=events+1
        print msg
"""
              
