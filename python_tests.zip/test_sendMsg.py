#!/usr/bin/env python

import encr_msg
import time
for i in range(10):
    ret=encr_msg.send_msg(i)
    print i,len(ret)
    time.sleep(3)
