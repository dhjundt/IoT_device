# -*- coding: utf-8 -*-
"""
Rasperry Pi 
@author: djundt
function readkey
report tuple (button pressed, char, time pressed)
only reports character if 'button pressed'=False (when finger lifted)
and button had been pressed for a minimum amount of time
"""
import RPi.GPIO as GPIO
import time
#globals
prevval=(False,' ',0.0)
tstart=0.0

# use GPIO connector numbering (B+)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#setup row outputs
rows=[10,9,11,5]
for i in rows:
    GPIO.setup(i,GPIO.OUT, initial=GPIO.LOW)
#LED
GPIO.setup(24,GPIO.OUT, initial=GPIO.LOW)

#setup col inputs
cols=[6,13,26]
for c in cols:
    GPIO.setup(c,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)  #1-*; 2-0; 3-#

#setLED is used to show a key is pressed or code was wrong
def setLED(on):
    GPIO.output(24,on)

#reads keyboard buttons
keymap=[['1','2','3'],['4','5','6'],['7','8','9'],['#','0','#']]
def readkey():
    global prevval
    global tstart
    tmin=0.05 #require button to be pressed >50ms or disregard
    previous=prevval
    ans=' '
    for i in range(len(rows)):
        GPIO.output(rows[i],True)
        for j in range(len(cols)):
            if (GPIO.input(cols[j])):
                ans=keymap[i][j]
        GPIO.output(rows[i],False)
    if ans==' ': #not pressed now
        if (previous[0]): #first no longer pressed
            setLED(False)
            if time.time()-tstart>tmin:
                prevval=(False,previous[1],time.time()-tstart)
            else: #too short
                prevval=(False,' ',0.0)
        else: 
            prevval=(False,' ',0.0)
    else: #pressed now
        if (previous[0]): #also previously
            prevval = (True,ans,0.0)
        else:
            tstart=time.time()
            setLED(True)
            prevval = (True,ans,time.time()-tstart)            
    return prevval


#main program
print 'push any buttons (total of 20 pushes)'
events=0
while events<20:
    (pressed,char,t_pressed)=readkey()
    if (not pressed and char<>' '):
        events=events+1
        print char,' pressed for ',round(t_pressed,2),' s'


            
                
